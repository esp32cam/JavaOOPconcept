import java.sql.Blob;

public class Math_tutorial {
    // Attribute
    private Double A;
    private Double B;
    private Double C;
    private Double D;
    private Double E; 
    private Double F;
    private Double G;
    private Double H;

    // Method
    public void getVariable(Double A,
                         Double B, 
                         Double C, 
                         Double D, 
                         Double E, 
                         Double F, 
                         Double G, 
                         Double H){
        this.A=A;
        this.B=B;
        this.C=C;
        this.D=D;
        this.E=E;
        this.F=F;
        this.G=G;
        this.H=H;
    }

    public void getVariable(int A,
                            int B,
                            int C){
        this.A=(double) A;
        this.B=(double) B;
        this.C=(double) C;                    
    }

    public void getVariable(int A,
                            double B){
        this.A=(double) A;
        this.B=(double) B;   
    }

    public void getVariable(double A,
                            double B){
         this.A=A;
         this.B=B;                       
    }

    public void FormulaMethod(){
        double Formula1 = A + B * C / (D * E) - (F + G) - H;
        System.out.println("A + B * C / (D * E) – (F + G) – H = "
        + Formula1);
    }

    public void QuadraticFormula(){
        double x = (-B*(Math.sqrt(Math.pow(B,2)-4*A*C))/2*A);
        System.out.println(x);
    }

    public void BMIFormula(){
        double weight = A;
        double height = B;
        double bmi = weight/ Math.pow(height,2);
        System.out.println(bmi);
    }

    public void Temperature_Converter(){
        double celsius = A;
        double fahrenheit = B;
        double celsius_convert = (B-32) * 5/9; 
        double fahrenheit_convert = A *9/5 + 32;
        System.out.println("fahrenheit add celsius: " + celsius + "C = "
        + fahrenheit_convert);
        System.out.println("celsius add fahrenheit: " + fahrenheit + "F = " 
        + celsius_convert);
    }
}
